#pragma once

#include "UtilityFunctions.h"

#include "sisl.h"
#include "GoReadWrite.h"

#include <fstream>
#include <string>


SISLSurf* read_tow_file(const std::string& filename);

BMesh convert_tow_file_to_mesh(const std::string& filename);

/// Creates a triangle surface mesh from a SISL Library surface
BMesh create_tow_surface_mesh(SISLSurf* surf_to_mesh);

std::unique_ptr<BMesh> create_tow_surface_mesh_evaluations(SISLSurf* surf_to_mesh);

void detect_intersections(SISLSurf* surf1, SISLSurf* surf2, SISLIntcurve** &intersections, int& num_intersections);

list<unique_ptr<Curve>> create_curves(SISLIntcurve **& intersections, const int& num_intersections);

void remove_edge_elements(BMesh& mesh);

