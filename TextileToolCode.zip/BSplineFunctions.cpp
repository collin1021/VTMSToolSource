#include "BSplineFunctions.h"

#include <sstream>

using namespace std;
using namespace BetaMesh;

SISLSurf * read_tow_file(const std::string & filename)
{
    ifstream is_sf(filename.c_str());
    if (!is_sf)
        throw runtime_error("Could not open input files.");


    cout << "Reading Tow 1...\n";
    string line;
    getline(is_sf, line);
    getline(is_sf, line);
    getline(is_sf, line);

    string temp, nump;
    getline(is_sf, line);
    stringstream ss1(line);
    int num_stacks, num_slice;
    ss1 >> temp;
    ss1 >> temp;
    num_stacks = stoi(temp);

	ss1 >> temp;
	ss1 >> temp;

	num_slice = stoi(temp);

    double* points = new double[num_stacks * num_slice * 3];
    int count = 0;
    for (int i = 0; i < num_stacks; i++)
    {
        getline(is_sf, line);
        for (int j = 0; j < num_slice; j++)
        {
            getline(is_sf, line);
            stringstream ss(line);
            ss >> temp;
            while (ss >> temp)
            {
                points[count] = (stod(temp));
                count++;
            }
        }
        getline(is_sf, line);
    }

    SISLSurf* result_surf = 0;
    int inbpnt1 = num_slice;
    int inbpnt2 = num_stacks;
    int jstat = 0;
    //cout << "pause" << endl;
    cout << "Calculating surface for Tow...";
    s1620(points,
        num_slice,
        num_stacks,
        1,
        0,
        1,
        4,
        4,
        3,
        &result_surf,
        &jstat);

    cout << "Done\n";
    if (jstat < 0) {
        throw runtime_error("Error inside 1536");
    }

    return result_surf;
}

BMesh convert_tow_file_to_mesh(const std::string& filename)
{
	ifstream is_sf(filename.c_str());
	if (!is_sf)
		throw runtime_error("Could not open input files.");


	cout << "Reading Tow 1...\n";
	string line;
	getline(is_sf, line);
	getline(is_sf, line);
	getline(is_sf, line);

	string temp, nump;
	getline(is_sf, line);
	stringstream ss1(line);
	int num_stacks, num_slice;
	ss1 >> temp;
	ss1 >> temp;
	num_stacks = stoi(temp);

	ss1 >> temp;
	ss1 >> temp;

	num_slice = stoi(temp);

	double* points = new double[num_stacks * num_slice * 3];
	int count = 0;
	for (int i = 0; i < num_stacks; i++)
	{
		getline(is_sf, line);
		for (int j = 0; j < num_slice; j++)
		{
			getline(is_sf, line);
			stringstream ss(line);
			ss >> temp;
			while (ss >> temp)
			{
				points[count] = (stod(temp));
				count++;
			} 
		}
		getline(is_sf, line);
	}

	BMesh mesh;

	count = 0;
	for (int i = 0; i < num_stacks; i++)
	{
		vector<BNodePtr> stack_nodes;
		for (int j = 0; j < num_slice; j++)
		{
			vector<double> coords;
			for (int k = 0; k < 3; k++)
			{
				coords.push_back(points[count]);
				count++;
			}
			
			if (j == 0) 
			{ 
				auto node = mesh.add_node_by_coord(coords); 
				stack_nodes.push_back(node);
			}
			else
			{
				auto node1 = mesh.nodes_back();
				auto node2 = mesh.add_node_by_coord(coords);
				stack_nodes.push_back(node2);
				auto tempele = mesh.add_element();
				tempele->initialize(ElemGeomType::L1D2N, { node1, node2 });

			}
		}

		auto tempele = mesh.add_element();
		tempele->initialize(ElemGeomType::L1D2N, { stack_nodes.back(), stack_nodes.front() });
	}
		mesh.update_global_numbering();

	return mesh;
}


/// Creates a triangle surface mesh from a SISL Library surface
BMesh create_tow_surface_mesh(SISLSurf * surf_to_mesh)
{
    //int num_of_surf_points = surf_to_mesh->in1 * surf_to_mesh->in2;



    BMesh surf_mesh;
    vector<BNodePtr> nodes;
    const int num_points_dir_1 = surf_to_mesh->in1;
    const int num_points_dir_2 = surf_to_mesh->in2;

    // Adds nodes in second parametric direction while looping over first direction
    for (int i = 0; i < num_points_dir_1; i++)
    {
        for (int j = 0; j < num_points_dir_2; j++)
        {
            // Equivalent to 3*p in SISL lib
            const int curr_vert_indx = i*num_points_dir_2 + j;
            auto coord = { surf_to_mesh->ecoef[3 * curr_vert_indx],
                surf_to_mesh->ecoef[3 * curr_vert_indx + 1],
                surf_to_mesh->ecoef[3 * curr_vert_indx + 2] };
            auto n = surf_mesh.add_node_by_coord(coord);
			nodes.push_back(n);
        }
    }

    //Makes two triangle elements out of four points
    for (int i = 0; i < num_points_dir_1 - 1; i++)
    {
        for (int j = 0; j < num_points_dir_2 - 1; j++)
        {
            const int row_i_vert_indx = j*num_points_dir_1 + i;
            const int row_i_p_1_vert_indx = (j + 1)*num_points_dir_1 + i;
            auto conn_1 = { nodes[row_i_vert_indx],
                nodes[row_i_p_1_vert_indx],
                nodes[row_i_vert_indx + 1] };

            auto conn_2 = { nodes[row_i_p_1_vert_indx],
                nodes[row_i_p_1_vert_indx + 1],
                nodes[row_i_vert_indx + 1] };

            auto tri_1 = surf_mesh.add_element();
            tri_1->initialize(ElemGeomType::T2D3N, conn_1);

            auto tri_2 = surf_mesh.add_element();
            tri_2->initialize(ElemGeomType::T2D3N, conn_2);
        }

    }

    return surf_mesh;
}

std::unique_ptr<BMesh> create_tow_surface_mesh_evaluations(SISLSurf * surf_to_mesh)
{
    //1421
    auto order_in_1_dir = surf_to_mesh->ik1 - 1;
    auto order_in_2_dir = surf_to_mesh->ik2 - 1;
    vector<double> points;
    for (int i = 0; i < surf_to_mesh->in2; i++)
    {
        for (int j = 0; j < surf_to_mesh->in1 + 1; j++)
        {
            int stat;
            double param_value[2] = { surf_to_mesh->et1[order_in_1_dir + j],surf_to_mesh->et2[order_in_2_dir + i] };
            int lefk1 = 0;
            int lefk2 = 0;
            double derive[18];
            double normal[3];
            s1421(surf_to_mesh, 1, param_value, &lefk1, &lefk2, derive, normal, &stat);
            points.push_back(derive[0]);
            points.push_back(derive[1]);
            points.push_back(derive[2]);
        }
    }
    auto surf_mesh = std::make_unique<BMesh>();
    vector<BNodePtr> nodes;
    const int num_points_dir_1 = surf_to_mesh->in1 + 1;
    const int num_points_dir_2 = surf_to_mesh->in2;

    // Adds nodes in second parametric direction while looping over first direction
    for (int i = 0; i < num_points_dir_1; i++)
    {
        for (int j = 0; j < num_points_dir_2; j++)
        {
            // Equivalent to 3*p in SISL lib
            const int curr_vert_indx = i*num_points_dir_2 + j;
            auto coord = { points[3 * curr_vert_indx],
                points[3 * curr_vert_indx + 1],
                points[3 * curr_vert_indx + 2] };
			auto n = surf_mesh->add_node_by_coord(coord);
			nodes.push_back(n);
        }
    }

    //Makes two triangle elements out of four points
    for (int i = 0; i < num_points_dir_1 - 1; i++)
    {
        for (int j = 0; j < num_points_dir_2 - 1; j++)
        {
            const int row_i_vert_indx = j*num_points_dir_1 + i;
            const int row_i_p_1_vert_indx = (j + 1)*num_points_dir_1 + i;
            auto conn_1 = { nodes[row_i_vert_indx],
                nodes[row_i_p_1_vert_indx],
                nodes[row_i_vert_indx + 1] };

            auto conn_2 = { nodes[row_i_p_1_vert_indx],
                nodes[row_i_p_1_vert_indx + 1],
                nodes[row_i_vert_indx + 1] };

            auto tri_1 = surf_mesh->add_element();
            tri_1->initialize(ElemGeomType::T2D3N, conn_1);
		//	tri_1->

            auto tri_2 = surf_mesh->add_element();
            tri_2->initialize(ElemGeomType::T2D3N, conn_2);
        }

    }

    return std::move(surf_mesh);
}

void detect_intersections(SISLSurf * surf1, SISLSurf * surf2, SISLIntcurve **& intersections, int & num_intersections)
{
    cout << "Detecting Intersections...";
    double epsco = 1.0e-15; // computational epsilon
    double epsge = 6.35e-8; // geometric tolerance
    int num_int_points = 0; // number of detected intersection points
    double* intpar_surf_1 = 0; // parameter values for the surface in the intersections
    double* intpar_surf_2 = 0; // parameter values for the curve in the intersections
    num_intersections = 0;   // number of intersection curves
    intersections = 0; // pointer to array of detected intersection curves
    int jstat = 0; // status variable

                   // calculating topology of intersections
    s1859(surf1,          // the first surface
        surf2,          // the second surface
        epsco,           // computational resolution
        epsge,           // geometry resolution
        &num_int_points, // number of single intersection points
        &intpar_surf_1,  // pointer to array of parameter values for surface 1
        &intpar_surf_2,  //               -"-                    for surface 2
        &num_intersections, // number of detected intersection curves
        &intersections,       // pointer to array of detected intersection curves.
        &jstat);         // status variable
    cout << "Done with status " << jstat << "\n";
    if (jstat < 0) {
        throw runtime_error("Error occured inside call to SISL routine s1859.");
    }
    else if (jstat > 0) {
        cerr << "WARNING: warning occured inside call to SISL routine s1859. \n"
            << endl;
    }

    cout << "Number of intersection points detected: " << num_int_points << endl;
    cout << "Number of intersection curves detected: " << num_intersections << endl;

    // evaluating (tracing out) intersection curves and writing them to file
    int i;
    for (i = 0; i < num_intersections; ++i) {
        s1310(surf1,          // the first surface
            surf2,          // the second surface
            intersections[i],     // pointer to the intersection curve object
            epsge,           // geometric tolerance
            double(0),       // maximum step size (ignored if <= 0)
            1,               // make only 3D curve (no 2D curve in parametric domain)
            0,               // don't draw the curve
            &jstat);
        if (jstat < 0) {
            throw runtime_error("Error occured inside call to SISL routine s1310.");
        }
        else if (jstat == 3) {
            throw runtime_error("Iteration stopped due to singular point or degenerate surface.");
        }
    }
}

list<unique_ptr<Curve>> create_curves(SISLIntcurve **& intersections, const int& num_intersections)
{

	///Condense curve data to just points in a vector
	vector<SISLCurve*> curves;
	for (int i = 0; i < num_intersections; i++)
	{
		curves.push_back(intersections[i]->pgeom);
	}


	vector<BNodePtr> nodes;
	vector <BElementPtr> elements;
	BMesh mesh;

	int nodecount = 0;
	int elemcount = 0;
	for (int i = 0; i < curves.size(); i++)
	{

		auto temp1 = mesh.add_node_by_coord({ curves[i]->ecoef[0], curves[i]->ecoef[1], curves[i]->ecoef[2] });
		nodes.push_back(temp1);
		nodecount++;
		for (int j = 1; j < curves[i]->in; j++)
		{

			auto temp2 = mesh.add_node_by_coord({ curves[i]->ecoef[3 * j], curves[i]->ecoef[3 * j + 1], curves[i]->ecoef[3 * j + 2] });
			nodes.push_back(temp2);
			nodecount++;
			auto tempele1 = mesh.add_element();
			tempele1->initialize(ElemGeomType::L1D2N, { nodes[nodecount - 2], nodes[nodecount - 1] });
		}
	}
	//cout << "Number of nodes before removal: " << mesh.nodes_size() << endl;
	//NodeTopology::set_compare_tolerance(1e-20);
	//MeshManipulation<BMesh>::remove_duplicate_nodes(mesh);
	mesh.update_global_numbering();
	cout << "Number of Nodes: " << mesh.nodes_size() << endl;
	cout << "Number of Mesh Elements: " << mesh.elements_size() << endl;

	set<BElementPtr, ConnHashComparison<BElement>> unique_elements;
	for (auto it = mesh.elements_begin(); it != mesh.elements_end(); )
	{
		if (unique_elements.find(it->get()) == unique_elements.end()) {
			unique_elements.insert(it->get());
			it++; /// Be sure to increment the iterator
		}
		/// If it already exists, then erase it from the mesh
		else {
			mesh.remove_element(it++); /// Remove then post increment
		}
	}



	cout << "Number of Unique Elements: " << unique_elements.size() << endl;
	/// Tell betamesh to save parent elemnets for each node
	mesh.update_parents();

	MeshIO<BMesh>::write_VTK_mesh_file(mesh, "MeshBeforeCurveDetection.vtk", false, false);

	list<unique_ptr<Curve>> curve_list;

	unsigned int currCurve = 1;
	///Iterate over all mesh nodes
	for (auto it = mesh.nodes_begin(); it != mesh.nodes_end(); it++)
	{
		// if (get_forward_list_size(mesh.get_parent_elements_of_node(*it)) != 2)
		//  cout << (*it)->get_global_number() << ": " << get_forward_list_size(mesh.get_parent_elements_of_node(*it)) << endl;
		///If node has only one parent element, start creating known open curve
		if (get_forward_list_size(mesh.get_parent_elements_of_node(it->get())) == 1)
		{

			///Set current element to single parent element
			auto current_ele = *(mesh.get_parent_elements_of_node(it->get()).begin());
			///
			if (unique_elements.find(current_ele) == unique_elements.end() ||
				current_ele->get_conn()[1] == it->get())
				continue;
			///Set Domain ID
			curve_list.push_back(unique_ptr<Curve>(new Curve()));
			curve_list.back()->set_number(currCurve);
			auto n1 = curve_list.back()->add_node_by_coord((*it)->get_coord());
			curve_list.back()->set_start_node(n1);
			auto n2 = curve_list.back()->add_node_by_coord(current_ele->get_conn()[1]->get_coord());
			auto e = curve_list.back()->add_element();
			e->initialize(ElemGeomType::L1D2N, { n1, n2 });
			curve_list.back()->set_end_node(n2);
			current_ele->set_domain_id(currCurve);
			unique_elements.erase(current_ele);

			while (true)
			{
				///Find connected element to previous element, initially the single parent
				auto connected_ele = get_connected_element(mesh, unique_elements, current_ele);
				///If returned element is a nullptr, open curve completed
				if (connected_ele == nullptr)
					break;

				auto nextN = curve_list.back()->add_node_by_coord(connected_ele->get_conn()[1]->get_coord());
				auto nextE = curve_list.back()->add_element();
				nextE->initialize(ElemGeomType::L1D2N, { curve_list.back()->get_last_node(), nextN });
				curve_list.back()->set_end_node(nextN);
				nextE->set_domain_id(currCurve);
				current_ele = connected_ele;
			}
			curve_list.back()->check_closed();
			currCurve++;
		}
	}


	cout << "Num curves " << currCurve - 1 << endl;
	MeshIO<BMesh>::write_VTK_mesh_file(mesh, "MeshAfterCurveDetection.vtk", false, false);

	for (auto iter1 = curve_list.begin(); iter1 != curve_list.end(); iter1++)
	{
		if ((*iter1)->get_type() == CurveType::Closed)
		{
			for (auto iter2 = curve_list.begin(); iter2 != curve_list.end();)
			{
				if (iter1 != iter2 && (*iter1)->overlaps(**iter2) == true)
				{
					curve_list.erase(iter2++);
				}
				else
					iter2++;
			}
		}
	}

	cout << "Num Curves after removal: " << curve_list.size() << endl;
	return curve_list;
}

void remove_edge_elements(BMesh& mesh)
{
	for (auto e_iter = mesh.elements_begin(); e_iter != mesh.elements_end();)
	{
		if ((*e_iter)->get_conn()[0] == (*e_iter)->get_conn()[1] ||
			(*e_iter)->get_conn()[0] == (*e_iter)->get_conn()[2] ||
			(*e_iter)->get_conn()[1] == (*e_iter)->get_conn()[2])
		{
			e_iter = mesh.remove_element(e_iter);
		}
		else { e_iter++; }
	}
}