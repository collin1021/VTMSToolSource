#include "BSplineFunctions.h"
#include "math.h"

using namespace std;
using namespace BetaMesh;

#ifdef _DEBUG

#define mycout std::cout << __FILE__ << "(" << __LINE__ << ")"
#define cout mycout

#endif

void add_segment_to_curve(Curve& curve, vector<vector<double>> segment, bool update = false)
{
	if (curve.elements_size() == 0)
	{
		auto n1 = curve.add_node_by_coord(segment[0]);
		auto n2 = curve.add_node_by_coord(segment[1]);
		auto e = curve.add_element();
		e->initialize(ElemGeomType::L1D2N, { n1, n2 });
		curve.set_start_node(n1);
		curve.set_end_node(n2);
	}
	else
	{
		auto n1 = curve.get_last_node();
		auto n2 = curve.add_node_by_coord(segment[1]);
		auto e = curve.add_element();
		e->initialize(ElemGeomType::L1D2N, { n1, n2 });
		curve.set_end_node(n2);
	}
	if (update)
	{
		curve.update_global_numbering();
		curve.update_local_numbering();
	}
}

Curve create_test_curve()
{
	Curve test_curve;
	add_segment_to_curve(test_curve, { { -0.2, 0.3, 0.0 },{ 0.1, 0.35, 0.0 } });
	add_segment_to_curve(test_curve, { {0.1, 0.35, 0.0 },{ 0.5, 0.1, 0.0 } });
	add_segment_to_curve(test_curve, { { 0.5, 0.1, 0 },{ 0.3, 1.0, 0.0 } });
	test_curve.update_global_numbering();
	test_curve.update_local_numbering();
	return test_curve;
}

BMesh create_single_triangle(vector<vector<double>> coords)
{
	BMesh mesh;
	auto n1 = mesh.add_node_by_coord(coords[0]);
	auto n2 = mesh.add_node_by_coord(coords[1]);
	auto n3 = mesh.add_node_by_coord(coords[2]);
	auto tempele1 = mesh.add_element();
	tempele1->initialize(ElemGeomType::T2D3N, { n1, n2, n3 });
	mesh.update_local_numbering();
	mesh.update_global_numbering();
	return mesh;
}

int main(int argc, char* argv[])
{
	//*
	/// Delcare paths for files
	auto tow_files = { "goodtows-1_Edited.stw",
		"goodtows-5_Edited.stw" };

    /// Output the mesh for viewing
    // MeshIO<BMesh>::write_VTK_mesh_file(intersection_curves_mesh, "IntersectionCurves.vtk", false, false);


	cout << "To proceed, press enter, or ^C to quit." << endl;


	try {
		cout << "Opening tow files...\n";

		vector<SISLSurf*> surfaces;
		for (auto tow_file : tow_files)
			surfaces.push_back(read_tow_file(tow_file));

		auto mesh1 = convert_tow_file_to_mesh(*tow_files.begin());
		//MeshIODistributed<BMesh>::write_pfec_files(mesh1, "STWformat");
		MeshIO<BMesh>::write_VTK_mesh_file(mesh1, "STWFORMAT.vtk", false, false);
		vector<std::unique_ptr<BMesh>> surf_meshes;
		surf_meshes.push_back(create_tow_surface_mesh_evaluations(surfaces[0]));
		//surf_meshes.push_back(create_tow_surface_mesh_evaluations(surfaces[1]));
        MeshIODistributed<BMesh>::write_pfec_files(*surf_meshes[0], "Mesh1Before");
        //MeshIODistributed<BMesh>::write_pfec_files(*surf_meshes[1], "Mesh2");
		MeshManipulation<BMesh>::remove_duplicate_nodes(*surf_meshes[0]);

		cout << "Elements before " << surf_meshes[0]->elements_size() << endl;
		remove_edge_elements(*surf_meshes[0]);
		cout << "Elements after " << surf_meshes[0]->elements_size() << endl;

		MeshIODistributed<BMesh>::write_pfec_files(*surf_meshes[0], "Mesh1After");
		//MeshManipulation<BMesh>::remove_duplicate_nodes(*surf_meshes[1]);

		surf_meshes[0]->update_global_numbering();
		//surf_meshes[1]->update_global_numbering();
		if (surfaces.size() < 2) throw runtime_error("There are not enough surfaces to check for intersections.");
		SISLIntcurve** intersections = 0;
		int num_intersections;
		detect_intersections(surfaces[0], surfaces[1], intersections, num_intersections);
		//auto curve_list = create_curves(intersections, num_intersections);
		

		///Condense curve data to just points in a vector
		vector<SISLCurve*> curves;
		for (int i = 0; i < num_intersections; i++)
		{
			curves.push_back(intersections[i]->pgeom);
		}


		vector<BNodePtr> nodes;
		vector <BElementPtr> elements;
		BMesh mesh;

		int nodecount = 0;
		int elemcount = 0;
		for (int i = 0; i < curves.size(); i++)
		{

			auto temp1 = mesh.add_node_by_coord({ curves[i]->ecoef[0], curves[i]->ecoef[1], curves[i]->ecoef[2] });
			nodes.push_back(temp1);
			nodecount++;
			for (int j = 1; j < curves[i]->in; j++)
			{

				auto temp2 = mesh.add_node_by_coord({ curves[i]->ecoef[3 * j], curves[i]->ecoef[3 * j + 1], curves[i]->ecoef[3 * j + 2] });
				nodes.push_back(temp2);
				nodecount++;
				auto tempele1 = mesh.add_element();
				tempele1->initialize(ElemGeomType::L1D2N, { nodes[nodecount - 2], nodes[nodecount-1]});
			}
		}
		//cout << "Number of nodes before removal: " << mesh.nodes_size() << endl;
        //NodeTopology::set_compare_tolerance(1e-20);
		//MeshManipulation<BMesh>::remove_duplicate_nodes(mesh);
		mesh.update_global_numbering();
		cout << "Number of Nodes: " << mesh.nodes_size() << endl;
		cout << "Number of Mesh Elements: " << mesh.elements_size() << endl;

		set<BElementPtr, ConnHashComparison<BElement>> unique_elements;
		for (auto it = mesh.elements_begin(); it != mesh.elements_end(); )
		{
			if (unique_elements.find(it->get()) == unique_elements.end()) {
				unique_elements.insert(it->get());
				it++; /// Be sure to increment the iterator
			}
			/// If it already exists, then erase it from the mesh
			else {
				mesh.remove_element(it++); /// Remove then post increment
			}
		}



		cout << "Number of Unique Elements: " << unique_elements.size() << endl;
		/// Tell betamesh to save parent elemnets for each node
		mesh.update_parents();
		//MeshManipulation<BMesh>::remove_duplicate_nodes(mesh);
        //MeshIO<BMesh>::write_VTK_mesh_file(mesh, "MeshBeforeCurveDetection.vtk", false, false);

		list<unique_ptr<Curve>> curve_list;

		unsigned int currCurve = 1;
		///Iterate over all mesh nodes
		for (auto it = mesh.nodes_begin(); it != mesh.nodes_end(); it++)
		{
           // if (get_forward_list_size(mesh.get_parent_elements_of_node(*it)) != 2)
              //  cout << (*it)->get_global_number() << ": " << get_forward_list_size(mesh.get_parent_elements_of_node(*it)) << endl;
			///If node has only one parent element, start creating known open curve
			if (get_forward_list_size(mesh.get_parent_elements_of_node(it->get())) == 1)
			{

				///Set current element to single parent element
				auto current_ele = *(mesh.get_parent_elements_of_node(it->get()).begin());
				///
				if (unique_elements.find(current_ele) == unique_elements.end() ||
                    current_ele->get_conn()[1] == it->get())
					continue;
				///Set Domain ID
				curve_list.push_back(unique_ptr<Curve>(new Curve()));
                curve_list.back()->set_number(currCurve);
				auto n1 = curve_list.back()->add_node_by_coord((*it)->get_coord());
				curve_list.back()->set_start_node(n1);
				auto n2 = curve_list.back()->add_node_by_coord(current_ele->get_conn()[1]->get_coord());
				auto e = curve_list.back()->add_element();
				e->initialize(ElemGeomType::L1D2N, { n1, n2 });
				curve_list.back()->set_end_node(n2);
				current_ele->set_domain_id(currCurve);
                unique_elements.erase(current_ele);

				while (true)
				{
					///Find connected element to previous element, initially the single parent
					auto connected_ele = get_connected_element(mesh, unique_elements, current_ele);
					///If returned element is a nullptr, open curve completed
					if (connected_ele == nullptr)
						break;

					auto prevN = curve_list.back()->nodes_back();
					auto nextN = curve_list.back()->add_node_by_coord(connected_ele->get_conn()[1]->get_coord());
					auto nextE = curve_list.back()->add_element();
					nextE->initialize(ElemGeomType::L1D2N, { prevN, nextN });
					curve_list.back()->set_end_node(nextN);
					nextE->set_domain_id(currCurve);
					current_ele = connected_ele;
				}
				curve_list.back()->check_closed();
				currCurve++;
			}
		}


		cout << "Num curves " << currCurve - 1 << endl;

		for (auto iter1=curve_list.begin(); iter1!= curve_list.end(); iter1++)
		{
			if ((*iter1)->get_type() == CurveType::Closed)
			{
				for (auto iter2 = curve_list.begin(); iter2 != curve_list.end();)
				{
					if (iter1 != iter2 && (*iter1)->overlaps(**iter2) == true)
					{
						curve_list.erase(iter2++);
					}
					else
						iter2++;
				}
			}
		}

		cout << "Num Curves after removal: " << curve_list.size() << endl;

		MeshIO<BMesh>::write_VTK_mesh_file(mesh, "MeshAfterCurveRemoval.vtk", false, false);

	MeshIO<Curve>::write_VTK_mesh_file(*(*curve_list.begin()), "Curve1BeforeElementRefinement.vtk", false, false);
	///Refine if intersected loop below

    // We need the vector storage for the KD tree
    for (auto tow_mesh_iter = surf_meshes.begin(); tow_mesh_iter != surf_meshes.end(); tow_mesh_iter++)
        (*tow_mesh_iter)->build_vectors();

	for (auto curve_list_iter = curve_list.begin(); curve_list_iter != curve_list.end(); curve_list_iter++)
	{
		(*curve_list_iter)->update_global_numbering();
		(*curve_list_iter)->update_local_numbering();
		(*curve_list_iter)->build_vectors();
	}



	///For curves in list
	//for (auto curve_iter = curve_list.begin(); curve_iter != curve_list.end(); curve_iter++)
	//{
	auto curve_iter = curve_list.begin();
	cout << "On Curve " << (*curve_iter)->return_number() << "...";

	///Creating intersected element group names by intersecting curve and number
	string curve_name = "Curve" + to_string((*curve_iter)->return_number());


		///For tow mesh
		for (auto tow_mesh_iter = surf_meshes.begin(); tow_mesh_iter != surf_meshes.end(); tow_mesh_iter++)
		{
			///Create intersected element group
			set<BElementPtr> ele_group;

			move_element_nodes_to_curve(**tow_mesh_iter, **curve_iter, ele_group, 0.01);

			MeshIODistributed<BMesh>::write_pfec_files(**tow_mesh_iter, "Mesh1NodeMovement");

			///Call refine command
            (*curve_iter)->refine_curve_if_intersected(**tow_mesh_iter, ele_group);

			///For Debugging
			//MeshIO<Curve>::write_VTK_mesh_file(**curve_iter, "Curve1AfterElementRefinement_OLD.vtk", false, false);

			///Create and assign element group for intersected elements
			(*tow_mesh_iter)->create_element_group(curve_name);
			(*tow_mesh_iter)->add_elements_to_group(curve_name, ele_group);
		}
		cout << (*curve_iter)->elements_size();
		MeshIO<Curve>::write_VTK_mesh_file(**curve_list.begin(), "Curve1AfterElementRefinement.vtk", false, false);
		(*curve_iter)->reduce_curve_refinement();
		MeshIO<Curve>::write_VTK_mesh_file(**curve_list.begin(), "Curve1AfterReducedRefinement.vtk", false, false);
		/// Loop over tows again for submeshing
		for (auto tow_mesh_iter = surf_meshes.begin(); tow_mesh_iter != surf_meshes.end(); tow_mesh_iter++)
		{
			// We don't need the vectors any more and we can't remove elemnets while they are being stored
			(**tow_mesh_iter).do_not_store_vectors();

			///Loop over intersected elements
			for (auto& ele : (*tow_mesh_iter)->get_element_group(curve_name))
			{
				if (ele->get_conn().size() > 3)
				{
					cout << "here";
				}
				(*curve_iter)->submesh_element_if_intersected(ele, **tow_mesh_iter);
				//MeshIO<BMesh>::write_VTK_mesh_file(temp_submesh, "SubMeshedElement.vtk", false, false);
				//system("pause");
			}

			// Remove original elements that were submeshed from the tow mesh
			auto& intersected_tow_elements = (*tow_mesh_iter)->get_element_group(curve_name);
			for (auto eIter = (*tow_mesh_iter)->elements_begin(); eIter != (*tow_mesh_iter)->elements_end();)
			{
				if (intersected_tow_elements.find(eIter->get()) != intersected_tow_elements.end())
					eIter = (*tow_mesh_iter)->remove_element(eIter);
				else eIter++;
			}

			(*tow_mesh_iter)->clear_node_groups();
			(*tow_mesh_iter)->clear_element_groups();
		}
	//}

	MeshIO<Curve>::write_VTK_mesh_file(**curve_list.begin(), "Curve1AfterSubmesh.vtk", false, false);
	MeshIO<BMesh>::write_VTK_mesh_file(*surf_meshes[0], "Mesh1afterrefinement.vtk", false, false);
	MeshIODistributed<BMesh>::write_pfec_files(*surf_meshes[0], "Mesh1AfterRefinement");


	freeSurf(surfaces[1]);
		}
		catch (exception& e) {
			cerr << "Exception thrown: " << e.what() << endl;
			system("pause");
		}

		
/*
auto mesh = create_single_triangle({ {0,0,0}, {1,0,0}, {0,1,0} });

mesh.build_vectors();

MeshIO<BMesh>::write_VTK_mesh_file(mesh, "TestElement.vtk", false, false);

auto curve = create_test_curve();

MeshIO<BMesh>::write_VTK_mesh_file(curve, "CurveBEFORERefinement.vtk", false, false);
set<BElementPtr> group;

curve.refine_curve_if_intersected(mesh, group);

MeshIO<BMesh>::write_VTK_mesh_file(curve, "CurveAFTERRefinement.vtk", false, false);

mesh.do_not_store_vectors();
for (auto ele_iter = mesh.elements_begin(); ele_iter != mesh.elements_end();ele_iter++)
{
	curve.submesh_element_if_intersected((*ele_iter).get(), mesh);
}


MeshIO<BMesh>::write_VTK_mesh_file(mesh, "ElementAFTERRefinement.vtk", false, false);


/*

list<unique_ptr<Curve>> curve_list;
vector<BNodePtr> node_list;
auto Node1 = BNodePtr(new BNode({ 0, 0, 0 }));
auto Node2 = BNodePtr(new BNode({ 1.0, 0, 0 }));
auto Node3 = BNodePtr(new BNode({ 0.5, 0, 0 }));
auto Node4 = BNodePtr(new BNode({ 0.5, 0.00001, 0 }));
auto Node5 = BNodePtr(new BNode({ 0.5, 0.001, 0 }));
auto Node6 = BNodePtr(new BNode({ 0.5, 0.01, 0 }));
auto Node7 = BNodePtr(new BNode({ 0.5, -0.001, 0 }));
node_list.push_back(Node1);
node_list.push_back(Node2);
node_list.push_back(Node3);
node_list.push_back(Node4);
node_list.push_back(Node5);
node_list.push_back(Node6);
node_list.push_back(Node7);

curve_list.push_back(unique_ptr<Curve>(new Curve()));
curve_list.back()->set_number(0);
Node1 = curve_list.back()->add_node_by_coord({ 0, 0, 0 });
Node2 = curve_list.back()->add_node_by_coord({ 1.0, 0, 0 });
auto E1 = curve_list.back()->add_element();
curve_list.back()->set_start_node(Node1);

E1->initialize(ElemGeomType::L1D2N, { Node1, Node2 });
curve_list.back()->set_end_node(Node2);

BMesh mesh;
mesh.add_node_by_coord(Node1->get_coord());
mesh.add_node_by_coord(Node2->get_coord());
E1 = mesh.add_element();
E1->initialize(ElemGeomType::L1D2N, { Node1, Node2 });

int num_overlaps = 0;
for (int i = 2; i < node_list.size(); i++)
{
	auto first_curve = curve_list.begin();
	curve_list.push_back(unique_ptr<Curve>(new Curve));
	curve_list.back()->set_number(i - 1);
	curve_list.back()->set_start_node(node_list[i]);
	curve_list.back()->set_end_node(node_list[i]);

	mesh.add_node_by_coord(node_list[i]->get_coord());
	auto tempele1 = curve_list.back()->add_element();
	tempele1->initialize(ElemGeomType::L1D2N, { node_list[i], node_list[i - 1] });


	if (curve_list.back()->overlaps(**first_curve) == true)
		num_overlaps++;
}

cout << num_overlaps << endl;

MeshIO<BMesh>::write_VTK_mesh_file(mesh, "MeshForCheckingOverlaps.vtk", false, false);

system("pause");*/
	system("pause");

};